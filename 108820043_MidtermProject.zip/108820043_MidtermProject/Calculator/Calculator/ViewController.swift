//
//  ViewController.swift
//  Calculator
//
//  Created by sean on 2022/3/21.
//

import UIKit

extension String {
    var expression: NSExpression {
        return NSExpression(format: self)
    }
}

extension Double {
    var isInt: Bool {
        let intValue = Int(self)
        return  Double(intValue) == self
    }
}

extension NSExpression {

    func toFloatingPoint() -> NSExpression {
        switch expressionType {
        case .constantValue:
            if let value = constantValue as? NSNumber {
                return NSExpression(forConstantValue: NSNumber(value: value.doubleValue))
            }
        case .function:
           let newArgs = arguments.map { $0.map { $0.toFloatingPoint() } }
           return NSExpression(forFunction: operand, selectorName: function, arguments: newArgs)
        case .conditional:
           return NSExpression(forConditional: predicate, trueExpression: self.true.toFloatingPoint(), falseExpression: self.false.toFloatingPoint())
        case .unionSet:
            return NSExpression(forUnionSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .intersectSet:
            return NSExpression(forIntersectSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .minusSet:
            return NSExpression(forMinusSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .subquery:
            if let subQuery = collection as? NSExpression {
                return NSExpression(forSubquery: subQuery.toFloatingPoint(), usingIteratorVariable: variable, predicate: predicate)
            }
        case .aggregate:
            if let subExpressions = collection as? [NSExpression] {
                return NSExpression(forAggregate: subExpressions.map { $0.toFloatingPoint() })
            }
        case .anyKey:
            fatalError("anyKey not yet implemented")
        case .block:
            fatalError("block not yet implemented")
        case .evaluatedObject, .variable, .keyPath:
            break // Nothing to do here
        @unknown default:
            fatalError("unknown error")
        }
        return self
    }
}

class ViewController: UIViewController {
    
    
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var clearLabel: UIButton!
    @IBOutlet weak var calculateLabel: UILabel!
    @IBOutlet weak var divideLabel: UIButton!
    @IBOutlet weak var mutiplyLabel: UIButton!
    @IBOutlet weak var substractLabel: UIButton!
    @IBOutlet weak var addLabel: UIButton!
    
    var formula:String = ""{
        didSet{
            calculateLabel.text = formula
        }
    }
    
    let operators = ["+", "-", "*", "/"]
    let operatorSet = CharacterSet(["+", "-", "*", "/"])
    let symbolSet = CharacterSet(["+", "-", "*", "/", "(", ")"])
    
    @IBAction func clear(_ sender: UIButton) {
        if sender.currentTitle == "C" {
            if !operators.contains(String(formula.suffix(1))) {
                formula.removeLast(formula.components(separatedBy: operatorSet).last!.count)
                checkState()
            }
            sender.setTitle("AC", for: .normal)
        } else if sender.currentTitle == "AC" {
            formula = ""
            resultLabel.text = "0"
            lightUp()
        }
    }
    
    @IBAction func numberControl(_ sender: UIButton) {
        var lastTwo: String? = nil
        if sender.currentTitle == "0" {
            if formula.count > 1 {
                lastTwo = String(formula.suffix(2))
            }
            if formula == "0" || formula == "-0" {
                formula.removeLast()
            } else if (lastTwo != nil), lastTwo?.suffix(1) == "0", operators.contains(String((lastTwo?.prefix(1))!)) {
                formula.removeLast()
            }
        } else {
            var count = 0
            for char in formula.reversed() {
                if operators.contains(String(char)) {
                    break
                }
                count += 1
            }
            while count != 0 {
                if formula[formula.index(formula.endIndex, offsetBy: -count)] == "0" {
                    formula.remove(at: formula.index(formula.endIndex, offsetBy: -count))
                } else {
                    break
                }
                count -= 1
            }
            
        }

        formula += sender.currentTitle ?? ""
        checkState()
    }
    
    @IBAction func equalControl(_ sender: UIButton) {
        if formula != "" {
            deleteZeros()
            if operators.contains(String(formula.suffix(1))) {
                formula += "0"
            }
            calculate(formula: formula)
        }
        checkState()
        clearLabel.setTitle("AC", for: .normal)
    }
    
    @IBAction func operatorControl(_ sender: UIButton) {
        if formula == "" {
            formula += "0"
            return
        }
        if sender.backgroundColor == #colorLiteral(red: 0.9987371564, green: 0.5848035216, blue: 0, alpha: 1) {
            changeColor(for: sender)
        }
        if operators.contains(String(formula.suffix(1))){
            formula.removeLast()
        }
        deleteZeros()
        formula += sender.currentTitle ?? ""
        checkState()
    }
    
    @IBAction func percentageControl(_ sender: UIButton) {
        resultLabel.text = (Double(resultLabel.text!)! / 100.0).description
        checkState()
    }
    
    @IBAction func positiveAndNegativeControl(_ sender: UIButton) {
        var temp = formula
        if formula != "" {
            temp.removeFirst()
        }
        if formula == "" {
            formula = "-0"
        } else if formula.prefix(2) == "-(" {
            formula.removeFirst()
            formula.removeFirst()
            formula.removeLast()
        } else if formula.prefix(1) == "-" && temp.rangeOfCharacter(from: operatorSet) == nil {
            formula.removeFirst()
        } else if formula.components(separatedBy: symbolSet).count == 1 {
            formula = "-" + formula
        } else {
            formula = "-(" + formula + ")"
        }
        checkState()
        clearLabel.setTitle("AC", for: .normal)
    }
    
    @IBAction func dotControl(_ sender: UIButton) {
        if String(formula.suffix(1)) == ")" {
            return
        }
        for char in formula.components(separatedBy: operatorSet).last! {
            if char == "." {
                return
            }
        }
        formula += sender.currentTitle ?? ""
    }
    
    func calculate(formula: String) {
        if let answer = formula.expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double {
            if String(answer) == "inf" {
                resultLabel.text = "0"
            }
            else if (answer.isInt){
                resultLabel.text = Int(answer).description
            }else{
                resultLabel.text = answer.description
            }
        }
    }
    
    func checkState() {
        lightUp()
        clearButtonStatus()
        operatorStatus()
    }
    
    func lightUp() {
        for view in self.view.subviews as [UIView] {
            if let btn = view as? UIButton {
                if btn.backgroundColor == #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1) {
                    changeColor(for: btn)
                }
            }
        }
    }
    
    func clearButtonStatus() {
        if formula == "" {
            clearLabel.setTitle("AC", for: .normal)
        } else {
            clearLabel.setTitle("C", for: .normal)
        }
    }
    
    func operatorStatus() {
        if operators.contains(String(formula.suffix(1))) {
            switch String(formula.suffix(1)) {
            case "+":
                changeColor(for: addLabel)
            case "-":
                changeColor(for: substractLabel)
            case "*":
                changeColor(for: mutiplyLabel)
            case "/":
                changeColor(for: divideLabel)
            default:
                return
            }
        }
    }
    
    func deleteZeros() {
        var shouldDelete = false
        for char in formula.reversed() {
            if operators.contains(String(char)) {
                break
            }
            if char == "." {
                shouldDelete = true
                break
            }
        }
        if shouldDelete {
            for char in formula.reversed() {
                if char == "0" || char == "."{
                    formula.removeLast()
                } else {
                    break
                }
            }
            if operators.contains(String(formula.suffix(1))) || formula == "" {
                formula += "0"
            }
        }
    }
    
    func changeColor(for btn: UIButton) {
        if btn.backgroundColor == #colorLiteral(red: 0.9987371564, green: 0.5848035216, blue: 0, alpha: 1) {
            btn.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            btn.setTitleColor(#colorLiteral(red: 0.9987371564, green: 0.5848035216, blue: 0, alpha: 1), for: .normal)
        } else {
            btn.backgroundColor = #colorLiteral(red: 0.9987371564, green: 0.5848035216, blue: 0, alpha: 1)
            btn.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}


